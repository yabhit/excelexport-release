# ExcelExport

将 Excel 游戏数据表导出为 JSON / Lua / XML 的交互式导出工具。
**纯 Go 单可执行文件 + 本地 Web 界面**（浅灰主题），无需安装 Excel、无 VBA、无第三方 UI 依赖。
支持服务端/客户端字段分离、跨表引用、行列转置、多项目同时维护、
**鼠标拖选圈选多行、右键菜单批量勾选/置顶**。

## 快速开始

```sh
# 生成示例文件（data.xlsx + local.json + _export.csv + 基准输出）
go run ./cmd/gen_example

# 编译
go build -o excelexport.exe ./cmd/excelexport

# 运行（自动打开浏览器；关闭页面即退出）
.\excelexport.exe .\example\local.json
```

## 界面与操作

```
┌──────────────────────────┬────────────────────────────────────────────┐
│ [导出全部]                │ 项目路径  ExcelRoot [input][…]  ServerRoot [input][…] │
│ [导出勾选]                │           CSV      [input][…]  ClientRoot [input][…] │
│ [编辑CSV]                 ├────────────────────────────────────────────┤
│ ─────────────            │ 📌│☑│表格名   │Sheet│状态     │时间          │
│ 项目  [＋] [✕]            │   │☑│data.xlsx│Item │成功(2文件)│07-12 10:00   │
│ ▸ MyGame  ⤒/📌           │   │☐│NPC.xlsx │NPC  │          │              │
│   OtherGame              │                                            │
├──────────────────────────┴────────────────────────────────────────────┤
│ 日志                                                                   │
└──────────────────────────────────────────────────────────────────────┘
```

- **左侧列**：顶部操作按钮 `[导出全部]` `[导出勾选]` `[编辑CSV]`；下方项目列表（点选切换，行尾 `⤒/📌` 句柄或右键**置顶项目**），
  列表头 `＋`（新建项目，填名称 + `_export.csv` 路径，不存在自动创建）与 `✕`（删除本地条目，不动项目文件）。
- **路径区两列摆放**（ExcelRoot/ServerRoot 一列，CSV/ClientRoot 一列）：输入框右侧 `…` 弹出**系统目录/文件选择框**（CSV 选文件、其余选文件夹），也支持直接输入。
- **任务表格**：📌 置顶 / ☑ 勾选 / 表格名 / Sheet / 状态 / 时间。**左键单击行 = 勾选/取消**、点击 checkbox 或选中行按 `Space` 勾选，按 `P` 置顶；
  **按住左键拖动圈选多行**（浅蓝高亮），**右键菜单**：全部勾选 / 全部取消勾选 / 置顶选中 / 取消置顶选中（作用于圈选行，未圈选则整表）。
- **自动保存**：勾选/置顶/路径/项目增删即时写回 local.json，无保存按钮。`[编辑CSV]` 打开任务文件，保存后界面自动重载。
- 关闭浏览器页面后进程约 12 秒自动退出；`--no-browser` 只打印 URL（调试用）。

## 双文件模型

| 层 | 文件 | 内容 | 归属 |
|----|------|------|------|
| 团队 | 项目目录里的 `_export.csv` | 任务定义（表格路径 / Sheet / 导出文件） | 跟项目走，版本控制 |
| 个人 | 工具本地 `local.json` | 项目清单 + 本地路径 + 勾选/置顶 | 本地，不提交 |

### 项目任务文件 `_export.csv`

```csv
ExcelPath,ExcelName,SheetName,ServerDir,ServerFile,ClientDir,ClientFile
,data.xlsx,Item,data,item.json,data,item.lua
sub,NPC.xlsx,NPC,,,npc,npc.xml
```

- `ExcelPath`：数据 Excel 在 ExcelRoot 下的子目录（空 = 根目录）。
- `ServerDir/ServerFile` 都为空 = 无服务端输出；`ClientDir/ClientFile` 同理。
- 输出格式由文件名扩展名决定：`.json` / `.lua` / `.xml`。兼容旧 `_config.csv`（同列格式）。

### 个人文件 `local.json`

```json
{
  "version": 1,
  "projects": [
    {
      "name": "MyGame",
      "csv": "D:\\Work\\MyGame\\_export.csv",
      "excelRoot": "D:\\Work\\MyGame\\Excel",
      "serverRoot": "D:\\Work\\MyGame\\server\\data",
      "clientRoot": "D:\\Work\\MyGame\\client\\assets",
      "pinned": true,
      "checks": ["data.xlsx|Item"],
      "pins": ["data.xlsx|Item"]
    }
  ]
}
```

- `checks`/`pins` 是个人勾选/置顶，键为 `表格名|Sheet`，与 CSV 行序无关；CSV 重载后按键重新匹配。
- 导出状态/时间只在本次运行期间显示（服务端内存），不写回任何文件。

## 数据表格式（DSL v0.4）

每个数据 sheet 固定 5 行表头 + 数据行：

| 行 | 内容 | 示例 |
|----|------|------|
| 1 | cs 标记（cs/s/c/空） | `cs` `cs` `s` `c` |
| 2 | 字段名 | `id` `name` `atk` `def` |
| 3 | 类型标注 | `k` `s` `i` `i` |
| 4 | 中文说明 | `编号` `名称` `攻击` `防御` |
| 5+ | 数据 | `1001` `slime` `15` `5` |

### 类型标注

| 标注 | 含义 |
|------|------|
| `k` `i` `f` `s` `b` | 主键 / 整数 / 浮点 / 字符串 / 布尔（均裸写，无 `@` 前缀） |
| `i?` `i=0` | 可空 / 默认值 |
| `i#hp` | 指定输出键名 |
| `[` `]` `{` `}` | 数组 / 对象结构 |
| `r:Sheet` `r:Sheet#col` | 跨表引用：把被引用表匹配行展开成本字段（被引用表由引擎自动加载） |
| `/` | 行列互换标记（写在 A1 单元格），单行常量表用 |

完整规范见仓库根目录 `AGENTS.md`（`DSL_SPEC*.md` 为历史设计稿，以 AGENTS.md 和代码/测试为准）。

## 示例项目结构

```
example/
├── local.json          # 示例个人文件
├── _export.csv         # 示例团队任务文件
├── data.xlsx           # 示例数据（Item / Monster / DropTable / GlobalConst）
├── output/             # 实际导出结果
│   ├── server/  data/item.json monster.json drop_table.json  config/global_const.lua
│   └── client/  data/item.lua monster.lua drop_table.lua     config/global_const.lua
└── expected/           # 基准输出（与 output/ 一致，供 CI 对比）
```

## 构建与测试

```sh
# 测试（web API 全部用 httptest 覆盖）
go test ./...

# 生成示例
go run ./cmd/gen_example

# 构建
go build -o excelexport.exe ./cmd/excelexport
```

Go 环境变量设置（Windows）见仓库根目录 `AGENTS.md`。

## 架构

```
_export.csv ──> workspace.LoadProjectCSV（团队任务）
local.json ───> workspace.LoadLocal（个人项目/路径/勾选/置顶）
                  │ BuildExportConfig(p, tasks)
                  ▼
               engine (编排) ──> excel (excelize 只读) ──> lexer ──> parser ──> ir ──> resolver ──> generator (JSON/Lua/XML)
                  ▲
本地 Web UI ───────┘  net/http 服务(127.0.0.1:17890) + 内嵌原生 HTML/CSS/JS（浏览器里圈选/右键/勾选）
```

- 引擎只接收内存配置（`engine.New(cfg, opts).Run()`），不读任何 dashboard 文件。
- 状态/时间仅会话内存；勾选/置顶随 `[保存]` 写入 local.json。
- 前端心跳（3s）+ 看门狗（12s 无心跳退出）= 关页面即退出。

## 版本历史

- **v0.6.0** — 本地 Web UI：浏览器原生圈选/右键/勾选，替换终端 TUI（终端鼠标不可靠）；仅剩 excelize 一个依赖
- **v0.5.0** — 纯 exe + tview TUI；v4 双文件模型（团队 `_export.csv` + 个人 `local.json`）
- **v0.4.0** — cs 标记行 + 5 行表头 DSL
- **v0.2.0** — Go 语言重写，替代 VBA 版本
